"""
testing/blackbox/test_auth_playwright.py
Black-box auth UI tests using Playwright.
"""
import pytest

playwright = pytest.importorskip("playwright.sync_api")

BASE_URL = "http://127.0.0.1:5000"


@pytest.fixture(scope="module")
def page():
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        pg = browser.new_page()
        yield pg
        browser.close()


@pytest.mark.blackbox
class TestAuthPlaywright:

    def test_login_form_has_identifier_and_password(self, page):
        page.goto(f"{BASE_URL}/login")
        assert page.locator("input[name='identifier'], input[name='email']").count() >= 1
        assert page.locator("input[type='password']").count() >= 1

    def test_register_form_present(self, page):
        page.goto(f"{BASE_URL}/register")
        assert page.locator("form").count() >= 1

    def test_invalid_login_shows_error(self, page):
        page.goto(f"{BASE_URL}/login")
        page.fill("input[name='identifier']", "nobody@nowhere.com")
        page.fill("input[type='password']", "wrongpass")
        page.click("button[type='submit'], input[type='submit']")
        page.wait_for_load_state("networkidle")
        content = page.content().lower()
        assert ("invalid" in content or "error" in content
                or "incorrect" in content or "failed" in content)
