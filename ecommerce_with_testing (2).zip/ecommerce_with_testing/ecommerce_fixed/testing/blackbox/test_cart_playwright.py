"""
testing/blackbox/test_cart_playwright.py
Black-box cart UI tests using Playwright.
"""
import pytest

playwright = pytest.importorskip("playwright.sync_api")

BASE_URL = "http://127.0.0.1:5000"
TEST_EMAIL = "customer@test.com"
TEST_PASSWORD = "customer123"


@pytest.fixture(scope="module")
def logged_page():
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        pg = browser.new_page()
        pg.goto(f"{BASE_URL}/login")
        pg.fill("input[name='identifier']", TEST_EMAIL)
        pg.fill("input[type='password']", TEST_PASSWORD)
        pg.click("button[type='submit'], input[type='submit']")
        pg.wait_for_load_state("networkidle")
        yield pg
        browser.close()


@pytest.mark.blackbox
class TestCartPlaywright:

    def test_cart_page_accessible_when_logged_in(self, logged_page):
        logged_page.goto(f"{BASE_URL}/cart")
        assert logged_page.locator("body").is_visible()

    def test_product_page_has_add_to_cart_button(self, logged_page):
        logged_page.goto(f"{BASE_URL}/product/aula-f75-test")
        # Look for a button or form containing "cart"
        content = logged_page.content().lower()
        assert "cart" in content
