"""
testing/blackbox/test_public_pages_playwright.py
Black-box browser tests using Playwright.
Run separately: pytest testing/blackbox/ --run-blackbox

These tests require:
  1. pip install playwright
  2. playwright install chromium
  3. The Flask app must be running: python app.py (or use live_server fixture)
"""
import pytest

# Guard: skip entire file if playwright not installed
playwright = pytest.importorskip("playwright.sync_api")

BASE_URL = "http://127.0.0.1:5000"


@pytest.fixture(scope="module")
def browser_page():
    """Launch Chromium, yield a page, then close."""
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        yield page
        browser.close()


@pytest.mark.blackbox
class TestPublicPagesPlaywright:

    def test_home_page_title(self, browser_page):
        """Home page renders and has a non-empty title."""
        browser_page.goto(f"{BASE_URL}/")
        assert browser_page.title() != ""

    def test_products_page_loads(self, browser_page):
        browser_page.goto(f"{BASE_URL}/products")
        assert browser_page.url.endswith("/products") or "products" in browser_page.url

    def test_about_page_loads(self, browser_page):
        browser_page.goto(f"{BASE_URL}/about")
        assert browser_page.locator("body").is_visible()

    def test_contact_page_loads(self, browser_page):
        browser_page.goto(f"{BASE_URL}/contact")
        assert browser_page.locator("body").is_visible()

    def test_login_page_has_form(self, browser_page):
        browser_page.goto(f"{BASE_URL}/login")
        form = browser_page.locator("form")
        assert form.count() >= 1

    def test_404_page_rendered(self, browser_page):
        browser_page.goto(f"{BASE_URL}/this-page-does-not-exist-xyz")
        assert browser_page.locator("body").is_visible()
        # Should show something, not a blank screen
        content = browser_page.content()
        assert len(content) > 50
