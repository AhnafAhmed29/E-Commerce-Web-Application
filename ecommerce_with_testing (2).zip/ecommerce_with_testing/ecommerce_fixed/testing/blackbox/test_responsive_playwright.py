"""
testing/blackbox/test_responsive_playwright.py
Responsive layout smoke tests using Playwright viewports.
"""
import pytest

playwright = pytest.importorskip("playwright.sync_api")

BASE_URL = "http://127.0.0.1:5000"

VIEWPORTS = [
    {"name": "desktop", "width": 1280, "height": 800},
    {"name": "tablet",  "width": 768,  "height": 1024},
    {"name": "mobile",  "width": 375,  "height": 667},
]


@pytest.mark.blackbox
@pytest.mark.parametrize("vp", VIEWPORTS, ids=[v["name"] for v in VIEWPORTS])
def test_home_renders_at_viewport(vp):
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page(viewport={"width": vp["width"], "height": vp["height"]})
        page.goto(f"{BASE_URL}/")
        assert page.locator("body").is_visible()
        content = page.content()
        assert len(content) > 200
        browser.close()
