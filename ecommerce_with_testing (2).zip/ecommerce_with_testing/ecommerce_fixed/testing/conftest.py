"""
testing/conftest.py
─────────────────────────────────────────────────────────────────────────────
Central fixture file for the CSE412 E-Commerce Testing Suite.

Provides:
  - Flask app / test client fixtures with a temporary SQLite database
  - Seeded data: categories, brands, products, variants
  - Sample users: customer + admin
  - Logged-in client fixtures
  - Pre-seeded cart and order fixtures

All tests inherit from these fixtures; no test touches the production DB.
─────────────────────────────────────────────────────────────────────────────
"""
import json
import os
import sys
import tempfile
import pytest

# ── Make the project root importable ─────────────────────────────────────────
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


# ── App + DB setup ────────────────────────────────────────────────────────────

@pytest.fixture(scope="session")
def app():
    """
    Create a Flask application configured for testing.
    Uses a temporary SQLite database that is destroyed after the session.
    """
    from app import app as flask_app
    from models.db import db

    db_fd, db_path = tempfile.mkstemp(suffix=".db")

    flask_app.config.update(
        TESTING=True,
        SECRET_KEY="test-secret-key-do-not-use-in-prod",
        SQLALCHEMY_DATABASE_URI=f"sqlite:///{db_path}",
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
        WTF_CSRF_ENABLED=False,
        LOGIN_DISABLED=False,
        UPLOAD_FOLDER=tempfile.mkdtemp(),
        SERVER_NAME=None,
    )

    with flask_app.app_context():
        db.create_all()
        yield flask_app
        db.session.remove()
        db.drop_all()

    os.close(db_fd)
    os.unlink(db_path)


@pytest.fixture(scope="session")
def _db(app):
    """Raw db reference (session-scoped)."""
    from models.db import db
    return db


@pytest.fixture()
def db_session(_db):
    """
    Per-test database session with automatic rollback so tests are isolated.
    """
    connection = _db.engine.connect()
    transaction = connection.begin()

    yield _db.session

    _db.session.remove()
    transaction.rollback()
    connection.close()


@pytest.fixture()
def client(app):
    """Flask test client."""
    return app.test_client()


@pytest.fixture()
def app_ctx(app):
    """Push an application context."""
    with app.app_context():
        yield


# ── Seeded data fixtures ──────────────────────────────────────────────────────

@pytest.fixture(scope="session")
def sample_category(app):
    """Seed a Category (Keyboards) and return it."""
    from models.db import db
    from models.product import Category

    with app.app_context():
        cat = Category.query.filter_by(slug="keyboards").first()
        if not cat:
            cat = Category(name="Keyboards", slug="keyboards",
                           description="Mechanical and membrane keyboards")
            db.session.add(cat)
            db.session.commit()
            cat = Category.query.filter_by(slug="keyboards").first()
        return cat.id  # return ID so sub-fixtures can re-query


@pytest.fixture(scope="session")
def sample_brand(app):
    """Seed a Brand (AULA) and return its id."""
    from models.db import db
    from models.product import Brand

    with app.app_context():
        brand = Brand.query.filter_by(slug="aula").first()
        if not brand:
            brand = Brand(name="AULA", slug="aula")
            db.session.add(brand)
            db.session.commit()
            brand = Brand.query.filter_by(slug="aula").first()
        return brand.id


@pytest.fixture(scope="session")
def sample_product(app, sample_category, sample_brand):
    """Seed a Product with stock=15 and return its slug."""
    from models.db import db
    from models.product import Product

    with app.app_context():
        p = Product.query.filter_by(slug="aula-f75-test").first()
        if not p:
            p = Product(
                name="AULA F75 Test",
                slug="aula-f75-test",
                price=4500.0,
                original_price=5000.0,
                stock=15,
                description="Test keyboard product",
                short_description="A great keyboard",
                is_active=True,
                category_id=sample_category,
                brand_id=sample_brand,
            )
            db.session.add(p)
            db.session.commit()
        return "aula-f75-test"


@pytest.fixture(scope="session")
def out_of_stock_product(app, sample_category, sample_brand):
    """Seed a Product with stock=0."""
    from models.db import db
    from models.product import Product

    with app.app_context():
        p = Product.query.filter_by(slug="oos-product-test").first()
        if not p:
            p = Product(
                name="Out Of Stock Product Test",
                slug="oos-product-test",
                price=999.0,
                stock=0,
                is_active=True,
                category_id=sample_category,
                brand_id=sample_brand,
            )
            db.session.add(p)
            db.session.commit()
        return "oos-product-test"


@pytest.fixture(scope="session")
def sample_variant(app, sample_product):
    """Seed a ProductVariant for the sample product."""
    from models.db import db
    from models.product import Product
    from models.product_variant import ProductVariant

    with app.app_context():
        prod = Product.query.filter_by(slug=sample_product).first()
        v = ProductVariant.query.filter_by(
            product_id=prod.id, sku="AULA-F75-BLACK"
        ).first()
        if not v:
            v = ProductVariant(
                product_id=prod.id,
                sku="AULA-F75-BLACK",
                attributes={"color": "Black"},
                price_modifier=0.0,
                stock=10,
                is_active=True,
            )
            db.session.add(v)
            db.session.commit()
            v = ProductVariant.query.filter_by(
                product_id=prod.id, sku="AULA-F75-BLACK"
            ).first()
        return v.id


# ── User fixtures ─────────────────────────────────────────────────────────────

@pytest.fixture(scope="session")
def customer_user(app):
    """Create a sample customer user and return credentials dict."""
    from models.db import db
    from models.user import User

    creds = dict(email="customer@test.com", username="testcustomer",
                 password="customer123")
    with app.app_context():
        u = User.query.filter_by(email=creds["email"]).first()
        if not u:
            u = User(email=creds["email"], username=creds["username"],
                     password=creds["password"], user_type="customer",
                     first_name="Test", last_name="Customer")
            db.session.add(u)
            db.session.commit()
    return creds


@pytest.fixture(scope="session")
def admin_user(app):
    """Create a sample admin user and return credentials dict."""
    from models.db import db
    from models.user import User

    creds = dict(email="admin@test.com", username="testadmin",
                 password="admin1234")
    with app.app_context():
        u = User.query.filter_by(email=creds["email"]).first()
        if not u:
            u = User(email=creds["email"], username=creds["username"],
                     password=creds["password"], user_type="admin",
                     first_name="Test", last_name="Admin")
            db.session.add(u)
            db.session.commit()
    return creds


@pytest.fixture()
def logged_in_customer(client, customer_user):
    """Return a test client that is logged in as a customer."""
    client.post("/login", data={
        "identifier": customer_user["email"],
        "password": customer_user["password"],
    }, follow_redirects=True)
    yield client
    client.get("/logout", follow_redirects=True)


@pytest.fixture()
def logged_in_admin(client, admin_user):
    """Return a test client that is logged in as an admin."""
    client.post("/login", data={
        "identifier": admin_user["email"],
        "password": admin_user["password"],
    }, follow_redirects=True)
    yield client
    client.get("/logout", follow_redirects=True)


# ── Cart fixture ──────────────────────────────────────────────────────────────

@pytest.fixture()
def seeded_cart(app, logged_in_customer, sample_product):
    """
    Add the sample product to the customer's cart and return the client.
    Depends on logged_in_customer (which yields the client).
    """
    logged_in_customer.post(
        "/cart/add",
        data={"product_id_slug": sample_product, "quantity": 1},
        follow_redirects=True,
    )
    return logged_in_customer


# ── Order fixture ─────────────────────────────────────────────────────────────

@pytest.fixture()
def seeded_order(app, logged_in_customer, sample_product, customer_user):
    """
    Place an order for the customer and return the Order object id.
    """
    from models.db import db
    from models.user import User
    from models.product import Product
    from models.order import Cart, CartItem, Order, OrderItem
    import secrets

    with app.app_context():
        user = User.query.filter_by(email=customer_user["email"]).first()
        prod = Product.query.filter_by(slug=sample_product).first()

        cart = Cart(user_id=user.id)
        db.session.add(cart)
        db.session.flush()

        item = CartItem(cart_id=cart.id, product_id=prod.id, quantity=1)
        db.session.add(item)
        db.session.flush()

        order = Order(
            order_number=f"ORD-TEST-{secrets.token_hex(4).upper()}",
            user_id=user.id,
            status="pending",
            payment_status="pending",
            payment_method="cod",
            shipping_first_name="Test",
            shipping_last_name="Customer",
            shipping_street="123 Test St",
            shipping_city="Dhaka",
            shipping_phone="01700000000",
            shipping_email=customer_user["email"],
            subtotal=prod.price,
            shipping_cost=60.0,
            total=prod.price + 60.0,
        )
        db.session.add(order)
        db.session.flush()

        oi = OrderItem(
            order_id=order.id,
            product_id=prod.id,
            product_name=prod.name,
            price=prod.price,
            quantity=1,
        )
        db.session.add(oi)
        db.session.commit()
        return order.id
