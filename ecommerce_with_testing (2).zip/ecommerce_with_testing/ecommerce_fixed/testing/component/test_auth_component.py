"""
testing/component/test_auth_component.py
Component tests: auth route + AuthServiceFacade + Strategy pattern + Factory.

Design notes:
  - /register: on success, logs user in and redirects to / (302 → 200 after follow)
  - /logout: redirects to / (302 → 200 after follow); user is then a guest
  - /cart: accessible to both logged-in users AND guests (session-based)
  - /orders: requires login — redirects anonymous users to /login
  - /login: if already authenticated, immediately redirects to / (302)

ISOLATION NOTE:
  Tests that need a definitely-unauthenticated client must explicitly clear
  the session cookie before posting, because earlier tests in the suite may
  have left a logged-in session in the shared Flask-Login user_loader chain.
  We achieve this by using `client.get('/logout')` first to clear any session,
  OR by using `with client.session_transaction() as s: s.clear()`.
"""
import pytest
import secrets


@pytest.mark.component
class TestAuthComponent:

    # ── Shared helpers ─────────────────────────────────────────────────────
    def _ensure_logged_out(self, client):
        """Guarantee the client holds no authenticated session."""
        client.get("/logout", follow_redirects=True)
        with client.session_transaction() as sess:
            sess.clear()

    # ── Login ──────────────────────────────────────────────────────────────
    def test_login_with_valid_credentials(self, client, customer_user):
        """Auth route correctly delegates to Strategy; valid user logs in."""
        self._ensure_logged_out(client)
        r = client.post("/login", data={
            "identifier": customer_user["email"],
            "password":   customer_user["password"],
        }, follow_redirects=True)
        assert r.status_code == 200
        data = r.data.decode().lower()
        assert ("logout" in data or "welcome" in data or
                customer_user["username"].lower() in data or
                "dashboard" in data or "products" in data), (
            "Valid login must result in an authenticated landing page"
        )

    def test_login_with_invalid_password_shows_error(self, client, customer_user):
        """
        Strategy returns None for bad credentials; error flash is shown.
        Ensures the client is logged out first so /login doesn't
        short-circuit with a 302 redirect for already-authenticated users.
        """
        self._ensure_logged_out(client)
        r = client.post("/login", data={
            "identifier": customer_user["email"],
            "password":   "definitelywrong99",
        }, follow_redirects=False)
        # Login failure: app renders login.html directly (200) with flash
        assert r.status_code == 200, (
            f"Failed login must return login page (200), got {r.status_code}. "
            "If 302, the client was still authenticated from a prior test."
        )
        data = r.data.decode().lower()
        # The flash block renders: <div class="alert alert-error">Invalid credentials</div>
        assert ("invalid" in data or "credentials" in data or "login" in data), (
            "Bad credentials must trigger a visible error message on the login page"
        )

    # ── Register ───────────────────────────────────────────────────────────
    def test_register_creates_customer_via_factory(self, client, app):
        """
        POST /register uses AuthServiceFacade → CustomerFactory.
        Ensures the client is logged out so /register doesn't redirect
        immediately (it redirects authenticated users to /).
        On success: user is created in DB with user_type='customer'.
        """
        self._ensure_logged_out(client)

        suffix = secrets.token_hex(4)
        email    = f"comp_{suffix}@test.com"
        username = f"comp_{suffix}"

        r = client.post("/register", data={
            "email":            email,
            "username":         username,
            "password":         "compPass123",
            "confirm_password": "compPass123",
            "first_name":       "Comp",
            "last_name":        "Test",
        }, follow_redirects=True)

        assert r.status_code == 200

        # Verify the CustomerFactory persisted the user in the DB
        from models.user import User
        with app.app_context():
            u = User.query.filter_by(email=email).first()
            assert u is not None, (
                "Factory must persist the new user in the DB"
            )
            assert u.user_type == "customer", (
                "CustomerFactory must set user_type='customer'"
            )

    def test_duplicate_email_registration_rejected(self, client, customer_user):
        """Facade catches duplicate email and returns error flash."""
        self._ensure_logged_out(client)
        r = client.post("/register", data={
            "email":            customer_user["email"],   # already taken
            "username":         "brand_new_username_xyz",
            "password":         "pass1234",
            "confirm_password": "pass1234",
        }, follow_redirects=True)
        data = r.data.decode().lower()
        assert ("already" in data or "registered" in data
                or "error" in data or "taken" in data), (
            "Duplicate email registration must show an error"
        )

    # ── Logout ─────────────────────────────────────────────────────────────
    def test_logout_redirects_to_valid_page(self, logged_in_admin):
        """GET /logout always redirects to a valid page (200 after follow)."""
        r = logged_in_admin.get("/logout", follow_redirects=True)
        assert r.status_code == 200

    def test_logout_clears_authenticated_session(self, client, customer_user):
        """After logout, accessing /orders redirects to /login (session cleared)."""
        self._ensure_logged_out(client)

        # Login
        client.post("/login", data={
            "identifier": customer_user["email"],
            "password":   customer_user["password"],
        }, follow_redirects=True)

        # /orders must be accessible while logged in
        r = client.get("/orders", follow_redirects=True)
        assert r.status_code == 200

        # Logout
        client.get("/logout", follow_redirects=True)

        # /orders must now redirect to login
        r = client.get("/orders", follow_redirects=False)
        assert r.status_code == 302, (
            "After logout, protected pages must redirect to login"
        )
        location = r.headers.get("Location", "")
        assert "login" in location.lower(), (
            "Logout must clear the session — redirect target must be /login"
        )

    # ── Admin access control ───────────────────────────────────────────────
    def test_admin_can_access_dashboard(self, logged_in_admin):
        """Logged-in admin reaches /admin/dashboard (200)."""
        r = logged_in_admin.get("/admin/dashboard", follow_redirects=True)
        assert r.status_code == 200

    def test_customer_is_blocked_from_admin(self, logged_in_customer):
        """Customer is redirected away from /admin/dashboard."""
        r = logged_in_customer.get("/admin/dashboard", follow_redirects=True)
        data = r.data.decode().lower()
        # App redirects customer to / with flash "Access denied"
        assert (r.status_code in (200, 403) and
                ("access" in data or "denied" in data
                 or "products" in data or "home" in data)), (
            "Customer must not access the admin dashboard"
        )
