"""
testing/component/test_cart_component.py
Component test: cart route + CartServiceFacade + CartItem model.
"""
import pytest


@pytest.mark.component
class TestCartComponent:

    def _add(self, client, app, slug, qty=1):
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=slug).first()
            pid = p.id
        return client.post("/cart/add",
                           data={"product_id": pid, "quantity": qty},
                           follow_redirects=True)

    def test_add_creates_cart_item(self, logged_in_customer, sample_product, app):
        self._add(logged_in_customer, app, sample_product)
        from models.order import Cart, CartItem
        from models.user import User
        with app.app_context():
            u = User.query.filter_by(email="customer@test.com").first()
            cart = Cart.query.filter_by(user_id=u.id).first()
            assert cart is not None

    def test_cart_total_calculated(self, logged_in_customer, sample_product, app):
        self._add(logged_in_customer, app, sample_product)
        r = logged_in_customer.get("/cart")
        data = r.data.decode().lower()
        assert "total" in data

    def test_cart_update_quantity(self, logged_in_customer, sample_product, app):
        self._add(logged_in_customer, app, sample_product)
        from models.order import Cart, CartItem
        from models.user import User
        with app.app_context():
            u = User.query.filter_by(email="customer@test.com").first()
            cart = Cart.query.filter_by(user_id=u.id).first()
            if cart:
                item = cart.items.first()
                if item:
                    r = logged_in_customer.post(
                        f"/cart/update/{item.id}",
                        data={"quantity": 2},
                        follow_redirects=True,
                    )
                    assert r.status_code in (200, 302, 404)
