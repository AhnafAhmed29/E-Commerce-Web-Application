"""
testing/component/test_admin_component.py
Component test: admin routes + backend logic.
"""
import pytest


@pytest.mark.component
class TestAdminComponent:

    def test_admin_dashboard_shows_stats(self, logged_in_admin):
        r = logged_in_admin.get("/admin/dashboard", follow_redirects=True)
        assert r.status_code == 200
        data = r.data.decode().lower()
        assert "admin" in data or "dashboard" in data or "product" in data

    def test_admin_can_view_orders(self, logged_in_admin):
        r = logged_in_admin.get("/admin/orders", follow_redirects=True)
        assert r.status_code == 200

    def test_admin_products_list_populated(
        self, logged_in_admin, sample_product
    ):
        r = logged_in_admin.get("/admin/products", follow_redirects=True)
        assert r.status_code == 200
        # The product we seeded should be visible
        assert b"AULA" in r.data or b"product" in r.data.lower()
