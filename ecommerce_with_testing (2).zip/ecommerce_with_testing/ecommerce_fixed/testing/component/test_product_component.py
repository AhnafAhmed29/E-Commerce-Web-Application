"""
testing/component/test_product_component.py
Component test: product route + ProductServiceFacade + Product model.
"""
import pytest


@pytest.mark.component
class TestProductComponent:

    def test_products_route_calls_facade(self, client, sample_product):
        """The /products route correctly uses the facade to fetch products."""
        r = client.get("/products")
        assert r.status_code == 200
        # The facade returns products; the page should list them
        assert len(r.data) > 100

    def test_product_slug_route_resolves_correctly(self, client, sample_product):
        r = client.get(f"/product/{sample_product}")
        assert r.status_code == 200
        assert b"4500" in r.data or b"4,500" in r.data

    def test_category_filter_integrates(self, client, sample_product):
        r = client.get("/products?category=keyboards")
        assert r.status_code == 200

    def test_product_page_has_add_to_cart(self, client, sample_product):
        """Product detail page must have an Add to Cart button/form."""
        r = client.get(f"/product/{sample_product}")
        data = r.data.decode().lower()
        assert "add to cart" in data or "add_to_cart" in data or \
               "cart" in data
