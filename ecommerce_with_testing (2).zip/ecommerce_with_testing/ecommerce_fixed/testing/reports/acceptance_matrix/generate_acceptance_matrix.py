"""
testing/reports/acceptance_matrix/generate_acceptance_matrix.py
─────────────────────────────────────────────────────────────────────────────
Generates an acceptance test summary (CSV + HTML) from the JUnit XML
produced by pytest.

Run after running pytest:
  python testing/reports/acceptance_matrix/generate_acceptance_matrix.py

Output:
  testing/reports/acceptance_matrix/acceptance_summary.csv
  testing/reports/acceptance_matrix/acceptance_summary.html
─────────────────────────────────────────────────────────────────────────────
"""
import os
import csv
import xml.etree.ElementTree as ET
from datetime import datetime

JUNIT_XML = os.path.join(
    os.path.dirname(__file__), "..", "junit", "results.xml"
)
OUT_DIR = os.path.dirname(__file__)
CSV_OUT = os.path.join(OUT_DIR, "acceptance_summary.csv")
HTML_OUT = os.path.join(OUT_DIR, "acceptance_summary.html")

# Map of acceptance criteria codes to descriptions
AC_DESCRIPTIONS = {
    "test_ac01": ("US-01", "View Products"),
    "test_ac02": ("US-02", "View Product Details"),
    "test_ac03": ("US-03", "Add Product to Cart"),
    "test_ac04": ("US-04", "View and Manage Cart"),
    "test_ac05": ("US-05", "Responsive Website Access"),
    "test_ac06": ("US-06", "View Company Information"),
    "test_ac07": ("US-07", "Product Data Management"),
    "test_ac09": ("US-09", "Search Products"),
    "test_ac10": ("US-10", "Checkout-Ready Cart Summary"),
    "test_ac11": ("US-11", "Product Availability & Stock Status"),
    "test_ac12": ("US-12", "Website Performance & Reliability"),
    "test_ac13": ("US-13", "User & Admin Registration and Login"),
}

PRIORITY_MAP = {
    "US-01": "High", "US-02": "High", "US-03": "High",
    "US-04": "High", "US-13": "High",
    "US-05": "Medium", "US-06": "Medium", "US-07": "Medium",
    "US-09": "Medium", "US-11": "Medium",
    "US-10": "Low", "US-12": "Low",
}


def _lookup_us(test_name):
    for prefix, (us_id, title) in AC_DESCRIPTIONS.items():
        if prefix in test_name:
            return us_id, title
    return "N/A", "Other"


def parse_junit(xml_path):
    """Parse JUnit XML and return list of test result dicts."""
    results = []
    if not os.path.exists(xml_path):
        print(f"[WARN] JUnit XML not found at {xml_path}. "
              f"Run pytest first.")
        return results

    tree = ET.parse(xml_path)
    root = tree.getroot()

    # Handle both <testsuites> and <testsuite> as root
    testcases = root.findall(".//testcase")

    for tc in testcases:
        name = tc.attrib.get("name", "")
        classname = tc.attrib.get("classname", "")
        time_val = tc.attrib.get("time", "0")

        failed = tc.find("failure")
        errored = tc.find("error")
        skipped = tc.find("skipped")

        if skipped is not None:
            status = "SKIP"
        elif failed is not None or errored is not None:
            status = "REJECT"
        else:
            status = "ACCEPT"

        us_id, us_title = _lookup_us(name.lower())

        # Extract AC code from test name (e.g., test_ac01_1 → AC-01-1)
        ac_code = "N/A"
        parts = name.split("_")
        for i, p in enumerate(parts):
            if p.startswith("ac") and len(p) > 2:
                digits = p[2:]
                ac_code = f"AC-{digits}"
                if i + 1 < len(parts) and parts[i + 1].isdigit():
                    ac_code += f"-{parts[i + 1]}"
                break

        results.append({
            "number": len(results) + 1,
            "us_id": us_id,
            "us_title": us_title,
            "priority": PRIORITY_MAP.get(us_id, "—"),
            "ac_code": ac_code,
            "test_name": name,
            "classname": classname,
            "time": time_val,
            "status": status,
            "critical": "Yes" if us_id in (
                "US-01", "US-02", "US-03", "US-04", "US-13"
            ) else "No",
        })

    return results


def write_csv(results, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=[
            "number", "us_id", "us_title", "priority", "ac_code",
            "test_name", "critical", "status", "time"
        ])
        writer.writeheader()
        writer.writerows(results)
    print(f"[OK] CSV written → {path}")


def write_html(results, path):
    total = len(results)
    accepted = sum(1 for r in results if r["status"] == "ACCEPT")
    rejected = sum(1 for r in results if r["status"] == "REJECT")
    skipped = sum(1 for r in results if r["status"] == "SKIP")

    rows_html = ""
    for r in results:
        color = {
            "ACCEPT": "#d4edda",
            "REJECT": "#f8d7da",
            "SKIP":   "#fff3cd",
        }.get(r["status"], "white")
        rows_html += f"""
        <tr style="background:{color}">
          <td>{r['number']}</td>
          <td><strong>{r['us_id']}</strong></td>
          <td>{r['us_title']}</td>
          <td>{r['priority']}</td>
          <td>{r['ac_code']}</td>
          <td style="font-size:0.8em">{r['test_name']}</td>
          <td>{r['critical']}</td>
          <td><strong>{r['status']}</strong></td>
          <td>{r['time']}s</td>
        </tr>"""

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Acceptance Test Matrix — CSE412 E-Commerce</title>
  <style>
    body {{ font-family: Arial, sans-serif; margin: 2em; }}
    h1 {{ color: #333; }}
    .summary {{ display:flex; gap:2em; margin-bottom:1.5em; }}
    .badge {{ padding:.5em 1em; border-radius:4px; font-weight:bold; }}
    .pass {{ background:#d4edda; color:#155724; }}
    .fail {{ background:#f8d7da; color:#721c24; }}
    .skip {{ background:#fff3cd; color:#856404; }}
    table {{ border-collapse:collapse; width:100%; font-size:.9em; }}
    th {{ background:#343a40; color:white; padding:.6em .8em; text-align:left; }}
    td {{ padding:.5em .8em; border-bottom:1px solid #dee2e6; }}
    tr:hover {{ filter:brightness(0.95); }}
    .footer {{ margin-top:1.5em; color:#666; font-size:.8em; }}
  </style>
</head>
<body>
  <h1>📋 Acceptance Test Matrix</h1>
  <p>Project: CSE412 E-Commerce Web Application (Gadget Store)<br>
  Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>

  <div class="summary">
    <div class="badge pass">✅ Accepted: {accepted}</div>
    <div class="badge fail">❌ Rejected: {rejected}</div>
    <div class="badge skip">⏭ Skipped: {skipped}</div>
    <div class="badge" style="background:#e2e3e5">Total: {total}</div>
  </div>

  <table>
    <thead>
      <tr>
        <th>#</th><th>User Story</th><th>Title</th><th>Priority</th>
        <th>AC Code</th><th>Test Name</th><th>Critical</th>
        <th>Result</th><th>Time</th>
      </tr>
    </thead>
    <tbody>{rows_html}</tbody>
  </table>
  <div class="footer">
    Generated by testing/reports/acceptance_matrix/generate_acceptance_matrix.py
  </div>
</body>
</html>"""

    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"[OK] HTML report written → {path}")


if __name__ == "__main__":
    results = parse_junit(JUNIT_XML)
    if not results:
        print("[INFO] No test results found. Using placeholder data.")
        # Create a skeleton so the file always exists
        results = [
            {
                "number": 1, "us_id": "US-01",
                "us_title": "View Products",
                "priority": "High", "ac_code": "AC-01-1",
                "test_name": "(run pytest to populate)",
                "classname": "", "time": "0",
                "status": "SKIP", "critical": "Yes",
            }
        ]
    write_csv(results, CSV_OUT)
    write_html(results, HTML_OUT)
    print("\nDone. Open:")
    print(f"  {HTML_OUT}")
