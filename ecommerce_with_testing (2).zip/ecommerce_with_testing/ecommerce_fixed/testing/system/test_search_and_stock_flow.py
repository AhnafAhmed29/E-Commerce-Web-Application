"""
testing/system/test_search_and_stock_flow.py
System test: search → results → stock check flow.
"""
import pytest


@pytest.mark.system
class TestSearchAndStockFlow:

    def test_search_returns_matching_products(self, client, sample_product):
        r = client.get("/products?q=AULA")
        assert r.status_code == 200
        assert b"AULA" in r.data

    def test_search_empty_returns_no_results_message(self, client):
        r = client.get("/products?q=xyznonexistentproduct99999")
        assert r.status_code == 200
        data = r.data.decode().lower()
        assert "no" in data or "found" in data or "0" in data

    def test_oos_product_shows_stock_status(self, client, out_of_stock_product):
        r = client.get(f"/product/{out_of_stock_product}")
        assert r.status_code == 200
        data = r.data.decode().lower()
        assert "out of stock" in data or "unavailable" in data

    def test_in_stock_product_can_add_to_cart(
        self, logged_in_customer, sample_product, app
    ):
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=sample_product).first()
            pid = p.id
        r = logged_in_customer.post("/cart/add",
                                    data={"product_id": pid, "quantity": 1},
                                    follow_redirects=True)
        assert r.status_code == 200
