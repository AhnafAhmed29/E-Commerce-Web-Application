"""
testing/system/test_admin_product_management.py
System test: admin product management flow.
"""
import pytest
import secrets


@pytest.mark.system
class TestAdminProductManagement:

    def test_admin_dashboard_loads(self, logged_in_admin):
        r = logged_in_admin.get("/admin/dashboard", follow_redirects=True)
        assert r.status_code == 200

    def test_admin_products_list(self, logged_in_admin, sample_product):
        r = logged_in_admin.get("/admin/products", follow_redirects=True)
        assert r.status_code == 200

    def test_admin_add_product_form(self, logged_in_admin):
        r = logged_in_admin.get("/admin/products/add", follow_redirects=True)
        assert r.status_code == 200
        data = r.data.decode().lower()
        assert "product" in data or "add" in data or "form" in data

    def test_customer_cannot_access_admin_dashboard(self, logged_in_customer):
        r = logged_in_customer.get("/admin/dashboard", follow_redirects=True)
        data = r.data.decode().lower()
        # Should redirect away or show access denied
        assert "admin" not in data or "unauthorized" in data or \
               "login" in data or "access" in data or r.status_code == 403

    def test_anonymous_redirected_from_admin(self, client):
        r = client.get("/admin/dashboard", follow_redirects=False)
        assert r.status_code in (302, 403)
