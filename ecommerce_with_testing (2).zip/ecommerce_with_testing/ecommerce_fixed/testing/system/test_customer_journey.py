"""
testing/system/test_customer_journey.py
System test: full customer browsing and cart journey.

Design note:
  The app serves a guest/session cart for anonymous users (no @login_required
  on /cart), so the cart page returns 200 for everyone.  Login IS required for
  /orders and /checkout POST.
"""
import pytest


@pytest.mark.system
class TestCustomerJourney:
    """End-to-end: browse → product detail → add to cart → view cart."""

    def _get_product_id(self, app, slug):
        from models.product import Product
        with app.app_context():
            return Product.query.filter_by(slug=slug).first().id

    # ── Full happy-path journey ────────────────────────────────────────────
    def test_full_browse_to_cart_journey(
        self, logged_in_customer, sample_product, app
    ):
        """Complete journey: home → products → product detail → add to cart → cart."""
        c = logged_in_customer

        # Step 1 – home page
        r = c.get("/")
        assert r.status_code == 200, "Home page must load"

        # Step 2 – browse all products
        r = c.get("/products")
        assert r.status_code == 200, "Products page must load"

        # Step 3 – view product detail
        r = c.get(f"/product/{sample_product}")
        assert r.status_code == 200, "Product detail must load"
        assert b"AULA" in r.data, "Product name must be on detail page"

        # Step 4 – add to cart
        pid = self._get_product_id(app, sample_product)
        r = c.post("/cart/add",
                   data={"product_id": pid, "quantity": 1},
                   follow_redirects=True)
        assert r.status_code == 200, "Add-to-cart must succeed"

        # Step 5 – view cart
        r = c.get("/cart")
        assert r.status_code == 200, "Cart page must load after adding item"
        data = r.data.decode("utf-8").lower()
        assert "aula" in data or "cart" in data, (
            "Added product must appear on cart page"
        )

    # ── Anonymous user journey ─────────────────────────────────────────────
    def test_anonymous_user_can_browse_products(self, client, sample_product):
        """Anonymous users can freely browse the product catalogue."""
        r = client.get("/products")
        assert r.status_code == 200

    def test_anonymous_user_can_view_product_detail(self, client, sample_product):
        """Anonymous users can view product detail pages."""
        r = client.get(f"/product/{sample_product}")
        assert r.status_code == 200

    def test_anonymous_cart_accessible_as_guest(self, client):
        """
        The app allows guest carts via session_id, so /cart returns 200
        for anonymous users (no login_required decorator on this route).
        """
        r = client.get("/cart")
        assert r.status_code == 200, (
            "Guest cart must be accessible without login "
            "(app uses session-based guest carts)"
        )

    def test_orders_page_requires_login(self, client):
        """/orders IS protected — anonymous users are redirected to login."""
        r = client.get("/orders", follow_redirects=False)
        assert r.status_code == 302, (
            "/orders must redirect unauthenticated users to login"
        )
        location = r.headers.get("Location", "")
        assert "login" in location.lower(), (
            "Redirect from /orders must point to the login page"
        )

    # ── Login and session flow ─────────────────────────────────────────────
    def test_login_and_access_protected_page(self, client, customer_user):
        """User logs in and can then access /orders."""
        # Login
        r = client.post("/login", data={
            "identifier": customer_user["email"],
            "password": customer_user["password"],
        }, follow_redirects=True)
        assert r.status_code == 200

        # Access protected page
        r = client.get("/orders", follow_redirects=True)
        assert r.status_code == 200

    def test_logout_clears_protected_access(self, client, customer_user):
        """After logout the user is redirected away from protected pages."""
        # Login first
        client.post("/login", data={
            "identifier": customer_user["email"],
            "password": customer_user["password"],
        }, follow_redirects=True)

        # Logout
        client.get("/logout", follow_redirects=True)

        # Now /orders must redirect again
        r = client.get("/orders", follow_redirects=False)
        assert r.status_code == 302
