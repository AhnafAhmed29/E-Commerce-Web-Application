"""
testing/system/test_checkout_flow.py
System test: cart → checkout page flow.
"""
import pytest


@pytest.mark.system
class TestCheckoutFlow:

    def _add_to_cart(self, client, app, slug):
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=slug).first()
            pid = p.id
        client.post("/cart/add", data={"product_id": pid, "quantity": 1},
                    follow_redirects=True)

    def test_checkout_page_accessible_with_cart(
        self, logged_in_customer, sample_product, app
    ):
        self._add_to_cart(logged_in_customer, app, sample_product)
        r = logged_in_customer.get("/checkout", follow_redirects=True)
        assert r.status_code == 200

    def test_empty_cart_redirect_on_checkout(self, logged_in_customer):
        # Clear cart first by just going to checkout with presumably empty cart
        r = logged_in_customer.get("/checkout", follow_redirects=True)
        # Should either load or redirect — never crash
        assert r.status_code in (200, 302)

    def test_cart_summary_shows_subtotal(
        self, logged_in_customer, sample_product, app
    ):
        self._add_to_cart(logged_in_customer, app, sample_product)
        r = logged_in_customer.get("/cart")
        data = r.data.decode().lower()
        assert "total" in data or "subtotal" in data
