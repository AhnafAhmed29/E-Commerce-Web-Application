"""
testing/unit/test_services_cart_facade.py
Unit tests for CartServiceFacade.
"""
import pytest


@pytest.mark.unit
class TestCartServiceFacade:

    def test_get_or_create_cart_for_user(self, app, customer_user):
        with app.app_context():
            from services.facade import CartServiceFacade
            from models.user import User
            u = User.query.filter_by(email=customer_user["email"]).first()
            cart = CartServiceFacade.get_or_create_cart(user_id=u.id)
            assert cart is not None
            assert cart.user_id == u.id

    def test_add_item_to_cart(self, app, customer_user, sample_product):
        with app.app_context():
            from services.facade import CartServiceFacade
            from models.user import User
            from models.product import Product
            u = User.query.filter_by(email=customer_user["email"]).first()
            p = Product.query.filter_by(slug=sample_product).first()
            cart = CartServiceFacade.get_or_create_cart(user_id=u.id)
            ok, msg = CartServiceFacade.add_to_cart(cart, product_id=p.id, quantity=1)
            assert ok is True

    def test_cannot_exceed_stock(self, app, customer_user, sample_product):
        with app.app_context():
            from services.facade import CartServiceFacade
            from models.user import User
            from models.product import Product
            u = User.query.filter_by(email=customer_user["email"]).first()
            p = Product.query.filter_by(slug=sample_product).first()
            cart = CartServiceFacade.get_or_create_cart(user_id=u.id)
            ok, msg = CartServiceFacade.add_to_cart(cart, product_id=p.id, quantity=99999)
            assert ok is False

    def test_get_or_create_returns_existing_cart(self, app, customer_user):
        with app.app_context():
            from services.facade import CartServiceFacade
            from models.user import User
            u = User.query.filter_by(email=customer_user["email"]).first()
            cart1 = CartServiceFacade.get_or_create_cart(user_id=u.id)
            cart2 = CartServiceFacade.get_or_create_cart(user_id=u.id)
            assert cart1.id == cart2.id
