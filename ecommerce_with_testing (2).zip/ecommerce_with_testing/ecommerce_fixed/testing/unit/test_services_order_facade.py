"""
testing/unit/test_services_order_facade.py
Unit tests for OrderServiceFacade.
"""
import pytest


@pytest.mark.unit
class TestOrderServiceFacade:

    def test_get_user_orders_returns_list(self, app, admin_user):
        with app.app_context():
            from services.facade import OrderServiceFacade
            from models.user import User
            u = User.query.filter_by(email=admin_user["email"]).first()
            orders = OrderServiceFacade.get_user_orders(u.id)
            assert isinstance(orders, list)

    def test_get_order_by_id_returns_none_for_invalid(self, app):
        with app.app_context():
            from services.facade import OrderServiceFacade
            order = OrderServiceFacade.get_order_by_id(999999)
            assert order is None

    def test_get_order_by_id_returns_order(self, app, seeded_order):
        with app.app_context():
            from services.facade import OrderServiceFacade
            order = OrderServiceFacade.get_order_by_id(seeded_order)
            assert order is not None
            assert order.id == seeded_order
