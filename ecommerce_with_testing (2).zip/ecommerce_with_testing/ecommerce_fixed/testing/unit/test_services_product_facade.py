"""
testing/unit/test_services_product_facade.py
Unit tests for ProductServiceFacade.
Note: search_products returns a Pagination object, not a plain list.
"""
import pytest


@pytest.mark.unit
class TestProductServiceFacade:

    def test_get_all_products_paginated(self, app, sample_product):
        with app.app_context():
            from services.facade import ProductServiceFacade
            pag = ProductServiceFacade.get_all_products(page=1, per_page=12)
            assert pag is not None
            assert pag.total >= 1

    def test_get_product_by_slug(self, app, sample_product):
        with app.app_context():
            from services.facade import ProductServiceFacade
            p = ProductServiceFacade.get_product_by_slug(sample_product)
            assert p is not None
            assert p.slug == sample_product

    def test_get_product_by_slug_not_found(self, app):
        with app.app_context():
            from services.facade import ProductServiceFacade
            p = ProductServiceFacade.get_product_by_slug("does-not-exist-abc")
            assert p is None

    def test_search_products_returns_match(self, app, sample_product):
        """search_products returns a Pagination object; items contains results."""
        with app.app_context():
            from services.facade import ProductServiceFacade
            pag = ProductServiceFacade.search_products("AULA")
            slugs = [p.slug for p in pag.items]
            assert sample_product in slugs

    def test_search_products_no_results(self, app):
        """search for nonsense term → 0 items in pagination."""
        with app.app_context():
            from services.facade import ProductServiceFacade
            pag = ProductServiceFacade.search_products("zzz_totally_nonexistent_xyzzy")
            assert pag.total == 0

    def test_get_categories_returns_list(self, app, sample_category):
        with app.app_context():
            from services.facade import ProductServiceFacade
            cats = ProductServiceFacade.get_categories()
            assert isinstance(cats, list)
            assert len(cats) >= 1

    def test_get_featured_products(self, app):
        with app.app_context():
            from services.facade import ProductServiceFacade
            featured = ProductServiceFacade.get_featured_products()
            assert isinstance(featured, list)
