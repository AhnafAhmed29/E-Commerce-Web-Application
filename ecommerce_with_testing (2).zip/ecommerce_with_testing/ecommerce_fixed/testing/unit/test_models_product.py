"""
testing/unit/test_models_product.py
Unit tests for Product model methods and properties.
"""
import pytest


@pytest.mark.unit
class TestProductModelProperties:

    def test_has_discount_true(self, app, sample_product):
        """Product with original_price > price has a discount."""
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=sample_product).first()
            # original_price=5000, price=4500
            assert p.has_discount is True

    def test_has_discount_false_when_no_original_price(self, app, out_of_stock_product):
        """Product without original_price: has_discount is falsy (None or False)."""
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=out_of_stock_product).first()
            # The property returns `self.original_price and ...` → evaluates falsy when None
            assert not p.has_discount

    def test_get_discount_percentage_correct(self, app, sample_product):
        """Discount %: (5000-4500)/5000 * 100 = 10."""
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=sample_product).first()
            assert p.get_discount_percentage() == 10

    def test_get_discount_percentage_zero_when_no_discount(self, app, out_of_stock_product):
        """Products without discount return 0%."""
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=out_of_stock_product).first()
            assert p.get_discount_percentage() == 0

    def test_stock_status_in_stock(self, app, sample_product):
        """stock=15 → 'In Stock'."""
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=sample_product).first()
            assert p.stock_status == "In Stock"

    def test_stock_status_low_stock(self, app, sample_product):
        """stock=5 → 'Only 5 left'."""
        from models.db import db
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=sample_product).first()
            original = p.stock
            p.stock = 5
            db.session.commit()
            p = Product.query.filter_by(slug=sample_product).first()
            assert "5" in p.stock_status
            # Restore
            p.stock = original
            db.session.commit()

    def test_stock_status_out_of_stock(self, app, out_of_stock_product):
        """stock=0 → 'Out of Stock'."""
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=out_of_stock_product).first()
            assert p.stock_status == "Out of Stock"

    def test_is_in_stock_true(self, app, sample_product):
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=sample_product).first()
            assert p.is_in_stock is True

    def test_is_in_stock_false(self, app, out_of_stock_product):
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=out_of_stock_product).first()
            assert p.is_in_stock is False

    def test_get_attributes_from_active_variants(self, app, sample_product, sample_variant):
        """get_attributes() returns dict with colour options from active variants."""
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=sample_product).first()
            attrs = p.get_attributes()
            assert isinstance(attrs, dict)
            assert "color" in attrs
            assert "Black" in attrs["color"]

    def test_get_variant_stock_map(self, app, sample_product, sample_variant):
        """get_variant_stock_map() returns colour-to-stock mapping."""
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=sample_product).first()
            stock_map = p.get_variant_stock_map()
            assert isinstance(stock_map, dict)
            assert "color" in stock_map
            assert "Black" in stock_map["color"]
            assert stock_map["color"]["Black"] >= 0

    def test_get_images_returns_list_with_main(self, app, sample_product):
        """get_images() returns a list (at least empty — main_image may be None in tests)."""
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=sample_product).first()
            imgs = p.get_images()
            assert isinstance(imgs, list)

    def test_product_repr(self, app, sample_product):
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=sample_product).first()
            assert "AULA F75 Test" in repr(p)
