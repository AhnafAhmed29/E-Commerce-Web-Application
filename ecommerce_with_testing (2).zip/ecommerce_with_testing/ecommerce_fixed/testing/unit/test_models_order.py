"""
testing/unit/test_models_order.py
Unit tests for CartItem and OrderItem model methods.

SQLAlchemy models must be instantiated properly within an app context.
CartItem requires a real session to initialise _sa_instance_state;
we use transient objects via db.session.add then expunge to test logic
without persisting to the database.
"""
import json
import pytest


@pytest.mark.unit
class TestCartItemModel:

    def _make_transient_cart_item(self, app, slug, variant_attrs=None):
        """
        Create a transient CartItem (added then expunged) so all
        SQLAlchemy instrumentation is in place without a DB commit.
        """
        from models.db import db
        from models.product import Product
        from models.order import CartItem, Cart
        from models.user import User

        prod = Product.query.filter_by(slug=slug).first()
        # Use a dummy cart id — we only test methods, not persistence
        item = CartItem(
            cart_id=1,
            product_id=prod.id,
            quantity=2,
            variant_id=None,
            variant_attributes=json.dumps(variant_attrs) if variant_attrs else None,
        )
        # Attach the live product relationship manually
        item.product = prod
        return item, prod

    def test_unit_price_no_variant(self, app, sample_product):
        """unit_price without variant equals product.price."""
        with app.app_context():
            item, prod = self._make_transient_cart_item(app, sample_product)
            assert item.unit_price == prod.price

    def test_get_subtotal(self, app, sample_product):
        """get_subtotal() = unit_price * quantity."""
        with app.app_context():
            item, prod = self._make_transient_cart_item(app, sample_product)
            item.quantity = 2
            assert item.get_subtotal() == prod.price * 2

    def test_variant_display_none_when_no_attrs(self, app, sample_product):
        """variant_display returns None when no attributes set."""
        with app.app_context():
            item, _ = self._make_transient_cart_item(app, sample_product)
            assert item.variant_display is None

    def test_variant_display_with_attrs(self, app, sample_product):
        """variant_display renders colour attribute correctly."""
        with app.app_context():
            item, _ = self._make_transient_cart_item(
                app, sample_product, variant_attrs={"color": "Black"}
            )
            display = item.variant_display
            assert display is not None
            assert "Black" in display


@pytest.mark.unit
class TestOrderItemModel:

    def test_order_item_get_subtotal(self, app):
        """OrderItem.get_subtotal() = price * quantity."""
        with app.app_context():
            from models.order import OrderItem
            from models.product import Product
            prod = Product.query.first()
            assert prod is not None, "Need at least one product in DB"
            item = OrderItem(
                order_id=1,
                product_id=prod.id,
                product_name=prod.name,
                price=1000.0,
                quantity=3,
            )
            assert item.get_subtotal() == 3000.0

    def test_order_item_variant_display_standard(self, app):
        """variant_display returns 'Standard' when no attributes."""
        with app.app_context():
            from models.order import OrderItem
            from models.product import Product
            prod = Product.query.first()
            item = OrderItem(
                order_id=1,
                product_id=prod.id,
                product_name=prod.name,
                price=100.0,
                quantity=1,
                variant_attributes=None,
            )
            assert item.variant_display == "Standard"

    def test_order_item_variant_display_with_attrs(self, app):
        """variant_display shows attribute when set."""
        with app.app_context():
            from models.order import OrderItem
            from models.product import Product
            prod = Product.query.first()
            item = OrderItem(
                order_id=1,
                product_id=prod.id,
                product_name=prod.name,
                price=100.0,
                quantity=1,
                variant_attributes=json.dumps({"edition": "Pro"}),
            )
            assert "Pro" in item.variant_display
