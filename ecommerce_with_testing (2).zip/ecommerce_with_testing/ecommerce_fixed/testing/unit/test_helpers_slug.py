"""
testing/unit/test_helpers_slug.py
Unit tests for the generate_slug helper in app.py.
"""
import pytest


@pytest.mark.unit
class TestGenerateSlug:

    def test_basic_slug_no_spaces(self, app):
        with app.app_context():
            from app import generate_slug
            slug = generate_slug("Hello World Product")
            assert " " not in slug

    def test_slug_is_lowercase(self, app):
        with app.app_context():
            from app import generate_slug
            slug = generate_slug("Hello World Product")
            assert slug == slug.lower()

    def test_special_chars_removed(self, app):
        with app.app_context():
            from app import generate_slug
            slug = generate_slug("Product! @ #$%")
            assert "!" not in slug
            assert "@" not in slug

    def test_slug_uses_hyphens(self, app):
        with app.app_context():
            from app import generate_slug
            slug = generate_slug("My Great Keyboard")
            assert "-" in slug

    def test_duplicate_slug_gets_suffix(self, app, sample_product):
        """If base slug exists, a unique hex suffix is appended."""
        with app.app_context():
            from app import generate_slug
            # sample_product slug is "aula-f75-test" — already in DB
            slug = generate_slug("AULA F75 Test")
            assert isinstance(slug, str)
            assert len(slug) > 0
            # Must produce a different slug since the original exists
            assert slug != "aula-f75-test"

    def test_unique_product_name_slug(self, app):
        """A product name that doesn't exist produces a clean slug."""
        with app.app_context():
            from app import generate_slug
            slug = generate_slug("Completely Unique Gadget XYZ 99999")
            assert "completely" in slug
            assert "unique" in slug
