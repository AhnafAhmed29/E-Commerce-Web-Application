"""
testing/unit/test_factories_user_factory.py
Unit tests for the Factory Method pattern user factories.
Note: factories create model objects — SQLAlchemy mapper init requires app context.
"""
import pytest


@pytest.mark.unit
class TestCustomerFactory:

    def test_creates_customer_type(self, app):
        with app.app_context():
            from factories.user_factory import CustomerFactory
            f = CustomerFactory()
            u = f.create_user("c@factory.com", "factcust1", "password123")
            assert u.user_type == "customer"

    def test_invalid_email_raises(self, app):
        with app.app_context():
            from factories.user_factory import CustomerFactory
            f = CustomerFactory()
            with pytest.raises(ValueError):
                f.create_user("bademail", "user", "pass123")

    def test_short_password_raises(self, app):
        with app.app_context():
            from factories.user_factory import CustomerFactory
            f = CustomerFactory()
            with pytest.raises(ValueError):
                f.create_user("ok@test.com", "user", "abc")

    def test_kwargs_applied(self, app):
        with app.app_context():
            from factories.user_factory import CustomerFactory
            f = CustomerFactory()
            u = f.create_user("c@factory.com", "u1fact", "pass123",
                              first_name="Alice", last_name="Doe")
            assert u.first_name == "Alice"
            assert u.last_name == "Doe"


@pytest.mark.unit
class TestAdminFactory:

    def test_creates_admin_type(self, app):
        with app.app_context():
            from factories.user_factory import AdminFactory
            f = AdminFactory()
            u = f.create_user("a@factory.com", "adminfact1", "adminpass")
            assert u.user_type == "admin"


@pytest.mark.unit
class TestUserFactoryProvider:

    def test_get_customer_factory(self, app):
        with app.app_context():
            from factories.user_factory import UserFactoryProvider, CustomerFactory
            f = UserFactoryProvider.get_factory("customer")
            assert isinstance(f, CustomerFactory)

    def test_get_admin_factory(self, app):
        with app.app_context():
            from factories.user_factory import UserFactoryProvider, AdminFactory
            f = UserFactoryProvider.get_factory("admin")
            assert isinstance(f, AdminFactory)

    def test_unknown_type_raises(self, app):
        with app.app_context():
            from factories.user_factory import UserFactoryProvider
            with pytest.raises(ValueError):
                UserFactoryProvider.get_factory("superuser")

    def test_case_insensitive(self, app):
        with app.app_context():
            from factories.user_factory import UserFactoryProvider, CustomerFactory
            f = UserFactoryProvider.get_factory("CUSTOMER")
            assert isinstance(f, CustomerFactory)
