"""
testing/unit/test_models_user.py
Unit tests for the User model.
"""
import pytest


@pytest.mark.unit
class TestUserModel:

    def test_password_is_hashed(self, app, customer_user):
        from models.user import User
        with app.app_context():
            u = User.query.filter_by(email=customer_user["email"]).first()
            assert u.password_hash != customer_user["password"]

    def test_check_password_correct(self, app, customer_user):
        from models.user import User
        with app.app_context():
            u = User.query.filter_by(email=customer_user["email"]).first()
            assert u.check_password(customer_user["password"]) is True

    def test_check_password_wrong(self, app, customer_user):
        from models.user import User
        with app.app_context():
            u = User.query.filter_by(email=customer_user["email"]).first()
            assert u.check_password("wrongpass") is False

    def test_is_admin_customer(self, app, customer_user):
        from models.user import User
        with app.app_context():
            u = User.query.filter_by(email=customer_user["email"]).first()
            assert u.is_admin() is False

    def test_is_admin_admin_user(self, app, admin_user):
        from models.user import User
        with app.app_context():
            u = User.query.filter_by(email=admin_user["email"]).first()
            assert u.is_admin() is True

    def test_get_full_name(self, app, customer_user):
        from models.user import User
        with app.app_context():
            u = User.query.filter_by(email=customer_user["email"]).first()
            full = u.get_full_name()
            assert "Test" in full or len(full) > 0

    def test_user_repr(self, app, customer_user):
        from models.user import User
        with app.app_context():
            u = User.query.filter_by(email=customer_user["email"]).first()
            assert "testcustomer" in repr(u)
