"""
testing/unit/test_strategies_auth.py
Unit tests for the Strategy Pattern authentication classes.
"""
import pytest


@pytest.mark.unit
class TestUserAuthStrategy:

    def test_user_strategy_valid_creds(self, app, customer_user):
        with app.app_context():
            from strategies.auth_strategy import UserAuthenticationStrategy
            strat = UserAuthenticationStrategy()
            user = strat.authenticate(customer_user["email"], customer_user["password"])
            assert user is not None
            assert user.email == customer_user["email"]

    def test_user_strategy_wrong_password(self, app, customer_user):
        with app.app_context():
            from strategies.auth_strategy import UserAuthenticationStrategy
            strat = UserAuthenticationStrategy()
            user = strat.authenticate(customer_user["email"], "wrongpassword")
            assert user is None

    def test_user_strategy_unknown_email(self, app):
        with app.app_context():
            from strategies.auth_strategy import UserAuthenticationStrategy
            strat = UserAuthenticationStrategy()
            user = strat.authenticate("nobody@xyz.com", "pass")
            assert user is None

    def test_user_strategy_admin_access_denied(self, app, customer_user):
        with app.app_context():
            from strategies.auth_strategy import UserAuthenticationStrategy
            from models.user import User
            u = User.query.filter_by(email=customer_user["email"]).first()
            strat = UserAuthenticationStrategy()
            assert strat.can_access_admin(u) is False

    def test_user_strategy_by_username(self, app, customer_user):
        with app.app_context():
            from strategies.auth_strategy import UserAuthenticationStrategy
            strat = UserAuthenticationStrategy()
            user = strat.authenticate(customer_user["username"], customer_user["password"])
            assert user is not None


@pytest.mark.unit
class TestAdminAuthStrategy:

    def test_admin_strategy_returns_admin(self, app, admin_user):
        with app.app_context():
            from strategies.auth_strategy import AdminAuthenticationStrategy
            strat = AdminAuthenticationStrategy()
            user = strat.authenticate(admin_user["email"], admin_user["password"])
            assert user is not None

    def test_admin_strategy_rejects_regular_customer(self, app, customer_user):
        with app.app_context():
            from strategies.auth_strategy import AdminAuthenticationStrategy
            strat = AdminAuthenticationStrategy()
            user = strat.authenticate(customer_user["email"], customer_user["password"])
            assert user is None

    def test_admin_strategy_can_access_admin_true(self, app, admin_user):
        with app.app_context():
            from strategies.auth_strategy import AdminAuthenticationStrategy
            from models.user import User
            u = User.query.filter_by(email=admin_user["email"]).first()
            strat = AdminAuthenticationStrategy()
            assert strat.can_access_admin(u) is True

    def test_admin_strategy_can_access_admin_false_for_none(self, app):
        with app.app_context():
            from strategies.auth_strategy import AdminAuthenticationStrategy
            strat = AdminAuthenticationStrategy()
            assert not strat.can_access_admin(None)


@pytest.mark.unit
class TestAuthContext:

    def test_context_default_strategy_is_user(self, app, customer_user):
        with app.app_context():
            from strategies.auth_strategy import AuthenticationContext
            ctx = AuthenticationContext()
            user = ctx.authenticate(customer_user["email"], customer_user["password"])
            assert user is not None

    def test_context_switch_to_admin_rejects_customer(self, app, customer_user):
        with app.app_context():
            from strategies.auth_strategy import (
                AuthenticationContext, AdminAuthenticationStrategy,
            )
            ctx = AuthenticationContext()
            ctx.set_strategy(AdminAuthenticationStrategy())
            user = ctx.authenticate(customer_user["email"], customer_user["password"])
            assert user is None

    def test_context_admin_strategy_accepts_admin(self, app, admin_user):
        with app.app_context():
            from strategies.auth_strategy import (
                AuthenticationContext, AdminAuthenticationStrategy,
            )
            ctx = AuthenticationContext(AdminAuthenticationStrategy())
            user = ctx.authenticate(admin_user["email"], admin_user["password"])
            assert user is not None

    def test_convenience_function_authenticate_user(self, app, customer_user):
        with app.app_context():
            from strategies.auth_strategy import authenticate_user
            user = authenticate_user(customer_user["email"], customer_user["password"])
            assert user is not None

    def test_convenience_function_authenticate_admin(self, app, admin_user):
        with app.app_context():
            from strategies.auth_strategy import authenticate_admin
            user = authenticate_admin(admin_user["email"], admin_user["password"])
            assert user is not None

    def test_verify_admin_access(self, app, admin_user):
        with app.app_context():
            from strategies.auth_strategy import verify_admin_access
            from models.user import User
            u = User.query.filter_by(email=admin_user["email"]).first()
            assert verify_admin_access(u) is True
