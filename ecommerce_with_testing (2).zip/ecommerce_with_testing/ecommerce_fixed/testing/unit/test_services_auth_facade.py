"""
testing/unit/test_services_auth_facade.py
Unit tests for AuthServiceFacade.
"""
import pytest
import secrets


@pytest.mark.unit
class TestAuthServiceFacade:

    def test_register_new_user(self, app):
        with app.app_context():
            from services.facade import AuthServiceFacade
            suffix = secrets.token_hex(4)
            ok, msg, user = AuthServiceFacade.register_user(
                f"facade_{suffix}@test.com", f"facade_{suffix}", "testpass123"
            )
            assert ok is True
            assert user is not None
            assert "success" in msg.lower()

    def test_register_duplicate_email_fails(self, app, customer_user):
        with app.app_context():
            from services.facade import AuthServiceFacade
            ok, msg, user = AuthServiceFacade.register_user(
                customer_user["email"], "different_user_xyz", "pass1234"
            )
            assert ok is False
            assert user is None

    def test_register_duplicate_username_fails(self, app, customer_user):
        with app.app_context():
            from services.facade import AuthServiceFacade
            ok, msg, user = AuthServiceFacade.register_user(
                "uniqueemail_xyz@test.com", customer_user["username"], "pass1234"
            )
            assert ok is False

    def test_login_valid_customer(self, app, customer_user):
        with app.app_context():
            from services.facade import AuthServiceFacade
            ok, msg, user = AuthServiceFacade.login_user(
                customer_user["email"], customer_user["password"]
            )
            assert ok is True
            assert user is not None

    def test_login_invalid_password(self, app, customer_user):
        with app.app_context():
            from services.facade import AuthServiceFacade
            ok, msg, user = AuthServiceFacade.login_user(
                customer_user["email"], "wrongpassword"
            )
            assert ok is False
            assert user is None

    def test_login_admin_with_admin_flag(self, app, admin_user):
        with app.app_context():
            from services.facade import AuthServiceFacade
            ok, msg, user = AuthServiceFacade.login_user(
                admin_user["email"], admin_user["password"], is_admin=True
            )
            assert ok is True

    def test_login_customer_as_admin_fails(self, app, customer_user):
        with app.app_context():
            from services.facade import AuthServiceFacade
            ok, msg, user = AuthServiceFacade.login_user(
                customer_user["email"], customer_user["password"], is_admin=True
            )
            assert ok is False

    def test_get_user_by_id(self, app, customer_user):
        with app.app_context():
            from services.facade import AuthServiceFacade
            from models.user import User
            u = User.query.filter_by(email=customer_user["email"]).first()
            fetched = AuthServiceFacade.get_user_by_id(u.id)
            assert fetched is not None
            assert fetched.email == customer_user["email"]

    def test_get_user_by_invalid_id_returns_none(self, app):
        with app.app_context():
            from services.facade import AuthServiceFacade
            fetched = AuthServiceFacade.get_user_by_id(999999)
            assert fetched is None
