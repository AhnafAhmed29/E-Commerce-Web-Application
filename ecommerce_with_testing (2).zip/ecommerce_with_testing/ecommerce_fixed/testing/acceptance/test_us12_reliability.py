"""
testing/acceptance/test_us12_reliability.py
US-12: Website Performance & Reliability  |  Priority: LOW

Acceptance Criteria:
  AC-12-1  All pages load within acceptable time limits under normal usage.
  AC-12-2  Broken links or missing product data are not shown to users.
  AC-12-3  The system handles invalid requests gracefully.
  AC-12-4  The website remains functional across common browsers.
"""
import time
import pytest

PAGES = ["/", "/products", "/about", "/contact", "/login", "/register"]
MAX_RESPONSE_MS = 2000  # 2 seconds per page


@pytest.mark.acceptance
@pytest.mark.us12
class TestUS12Reliability:

    @pytest.mark.parametrize("route", PAGES)
    def test_ac12_1_page_loads_within_time_limit(self, client, route):
        """AC-12-1: Each key page loads in under 2 seconds."""
        start = time.time()
        resp = client.get(route)
        elapsed_ms = (time.time() - start) * 1000
        assert resp.status_code in (200, 302), (
            f"AC-12-1 FAIL: {route} returned {resp.status_code}"
        )
        assert elapsed_ms < MAX_RESPONSE_MS, (
            f"AC-12-1 FAIL: {route} took {elapsed_ms:.0f}ms "
            f"(limit {MAX_RESPONSE_MS}ms)"
        )

    def test_ac12_2_invalid_product_slug_not_server_error(self, client):
        """
        AC-12-2: Non-existent product slug is handled gracefully.
        The app flashes 'Product not found' and redirects to /products (302).
        Following the redirect must yield a valid 200 page, never a 500.
        """
        # Without following redirect: expect 302 redirect (not 500)
        resp = client.get("/product/does-not-exist-ever-99999",
                          follow_redirects=False)
        assert resp.status_code in (302, 404), (
            "AC-12-2 FAIL: Missing product must redirect (302) or 404, not 500"
        )
        # Following the redirect must yield a usable page
        resp_followed = client.get("/product/does-not-exist-ever-99999",
                                   follow_redirects=True)
        assert resp_followed.status_code == 200, (
            "AC-12-2 FAIL: After redirect, page must load successfully"
        )

    def test_ac12_3_unknown_route_returns_404(self, client):
        """AC-12-3: Unknown URLs return 404 gracefully, never 500."""
        resp = client.get("/this-route-does-not-exist-at-all")
        assert resp.status_code == 404, (
            "AC-12-3 FAIL: Unknown route must return 404, not 500"
        )

    def test_ac12_3_invalid_product_add_handled(self, logged_in_customer):
        """AC-12-3: Adding a non-existent product ID is handled gracefully."""
        resp = logged_in_customer.post(
            "/cart/add",
            data={"product_id": 999999, "quantity": 1},
            follow_redirects=True,
        )
        assert resp.status_code in (200, 302, 400, 404), (
            "AC-12-3 FAIL: Invalid product add must not cause 500"
        )

    def test_ac12_1_products_page_fast(self, client, sample_product):
        """AC-12-1: /products route loads in under 2 seconds."""
        start = time.time()
        client.get("/products")
        elapsed = time.time() - start
        assert elapsed < 2.0, (
            f"AC-12-1 FAIL: /products took {elapsed:.2f}s — exceeds 2s limit"
        )

    def test_ac12_3_server_does_not_crash_on_bad_cart_id(self, logged_in_customer):
        """AC-12-3: Invalid cart item IDs on update/remove are handled."""
        resp = logged_in_customer.post(
            "/cart/update/999999",
            data={"quantity": 1},
            follow_redirects=True,
        )
        assert resp.status_code in (200, 302, 404), (
            "AC-12-3 FAIL: Invalid cart item update must not crash server"
        )
