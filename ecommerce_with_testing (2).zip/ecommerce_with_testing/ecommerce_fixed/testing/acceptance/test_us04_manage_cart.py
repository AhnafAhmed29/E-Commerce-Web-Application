"""
testing/acceptance/test_us04_manage_cart.py
Acceptance Tests for US-04: View and Manage Cart  |  Priority: HIGH

Acceptance Criteria:
  AC-04-1  The cart page lists all added products.
  AC-04-2  The user can increase or decrease product quantities.
  AC-04-3  The system updates the total price dynamically.
  AC-04-4  The user can remove items from the cart.
"""
import pytest


@pytest.mark.acceptance
@pytest.mark.us04
class TestUS04ManageCart:

    def _add_item(self, client, app, slug):
        """Helper: add one unit of a product to the customer cart."""
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=slug).first()
            pid = p.id
        client.post("/cart/add",
                    data={"product_id": pid, "quantity": 1},
                    follow_redirects=True)
        return pid

    def _get_first_cart_item_id(self, app):
        """Return the first CartItem id for the test customer, or None."""
        from models.order import Cart
        from models.user import User
        with app.app_context():
            u = User.query.filter_by(email="customer@test.com").first()
            if not u:
                return None
            cart = Cart.query.filter_by(user_id=u.id).first()
            if not cart:
                return None
            item = cart.items.first()
            return item.id if item else None

    # ──────────────────────────────────────────────────────────────────
    # AC-04-1: Cart lists products
    # ──────────────────────────────────────────────────────────────────
    def test_ac04_1_cart_lists_added_products(
        self, logged_in_customer, sample_product, app
    ):
        """AC-04-1: Cart page shows the product that was added."""
        self._add_item(logged_in_customer, app, sample_product)
        response = logged_in_customer.get("/cart")
        assert response.status_code == 200
        data = response.data.decode("utf-8")
        assert "AULA F75" in data or "cart" in data.lower(), (
            "AC-04-1 FAIL: Cart page must list added products"
        )

    def test_ac04_1_empty_cart_shows_message(self, client):
        """AC-04-1: Guest/empty cart page still loads without error."""
        response = client.get("/cart")
        assert response.status_code == 200

    # ──────────────────────────────────────────────────────────────────
    # AC-04-2: Quantity update
    # ──────────────────────────────────────────────────────────────────
    def test_ac04_2_update_quantity_endpoint_exists(
        self, logged_in_customer, sample_product, app
    ):
        """AC-04-2: POST /cart/update/<id> endpoint responds correctly."""
        self._add_item(logged_in_customer, app, sample_product)
        item_id = self._get_first_cart_item_id(app)
        if item_id is None:
            pytest.skip("No cart item found — skipping quantity update test")

        response = logged_in_customer.post(
            f"/cart/update/{item_id}",
            data={"quantity": 2},
            follow_redirects=True,
        )
        assert response.status_code in (200, 302), (
            "AC-04-2 FAIL: Quantity update endpoint must return 200 or 302"
        )

    def test_ac04_2_invalid_item_update_handled(self, logged_in_customer):
        """AC-04-2: Updating a non-existent item does not crash the server."""
        response = logged_in_customer.post(
            "/cart/update/999999",
            data={"quantity": 2},
            follow_redirects=True,
        )
        assert response.status_code in (200, 302, 404), (
            "AC-04-2 FAIL: Invalid cart item update must not crash (500)"
        )

    # ──────────────────────────────────────────────────────────────────
    # AC-04-3: Total price visible
    # ──────────────────────────────────────────────────────────────────
    def test_ac04_3_cart_shows_total_price(
        self, logged_in_customer, sample_product, app
    ):
        """AC-04-3: Cart page displays the total order cost."""
        self._add_item(logged_in_customer, app, sample_product)
        response = logged_in_customer.get("/cart")
        data = response.data.decode("utf-8").lower()
        assert "total" in data, (
            "AC-04-3 FAIL: Cart page must display a total price"
        )

    # ──────────────────────────────────────────────────────────────────
    # AC-04-4: Remove item — GET /cart/remove/<id> (app uses GET, not POST)
    # ──────────────────────────────────────────────────────────────────
    def test_ac04_4_remove_item_from_cart(
        self, logged_in_customer, sample_product, app
    ):
        """
        AC-04-4: User can remove items from the cart.
        Route: GET /cart/remove/<item_id>  (app uses GET redirect, not POST)
        """
        self._add_item(logged_in_customer, app, sample_product)
        item_id = self._get_first_cart_item_id(app)
        if item_id is None:
            pytest.skip("No cart item found — skipping remove test")

        # The app uses a GET route for removal
        response = logged_in_customer.get(
            f"/cart/remove/{item_id}",
            follow_redirects=True,
        )
        assert response.status_code in (200, 302), (
            "AC-04-4 FAIL: Remove item must succeed (200 or 302)"
        )

    def test_ac04_4_remove_invalid_item_handled(self, logged_in_customer):
        """AC-04-4: Removing a non-existent item is handled gracefully."""
        response = logged_in_customer.get(
            "/cart/remove/999999",
            follow_redirects=True,
        )
        assert response.status_code in (200, 302, 404), (
            "AC-04-4 FAIL: Invalid remove must not crash server"
        )
