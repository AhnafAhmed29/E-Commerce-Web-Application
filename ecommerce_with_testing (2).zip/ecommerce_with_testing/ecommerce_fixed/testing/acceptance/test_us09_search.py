"""
testing/acceptance/test_us09_search.py
US-09: Search Products (Medium Priority)
"""
import pytest


@pytest.mark.acceptance
@pytest.mark.us09
class TestUS09Search:

    def test_ac09_1_search_input_exists(self, client):
        """AC-09-1: Search input is present in the header/page."""
        resp = client.get("/")
        data = resp.data.decode("utf-8").lower()
        assert "search" in data, "AC-09-1 FAIL: Search input must be present"

    def test_ac09_2_search_by_name_returns_results(
        self, client, sample_product
    ):
        """AC-09-2: Searching by product name returns matching results."""
        resp = client.get("/products?q=AULA")
        assert resp.status_code == 200
        data = resp.data.decode("utf-8")
        assert "AULA" in data or "product" in data.lower()

    def test_ac09_3_no_results_message(self, client):
        """AC-09-3: A 'no products found' message is shown for empty searches."""
        resp = client.get("/products?q=xyznonexistentproduct12345")
        assert resp.status_code == 200
        data = resp.data.decode("utf-8").lower()
        assert (
            "no product" in data
            or "not found" in data
            or "0 product" in data
            or "no result" in data
        ), "AC-09-3 FAIL: Must show 'no products found' for empty search"

    def test_ac09_4_search_by_category(self, client, sample_category):
        """AC-09-4: Filtering by category returns 200."""
        resp = client.get("/products?category=keyboards")
        assert resp.status_code == 200

    def test_ac09_5_search_loads_in_reasonable_time(self, client):
        """AC-09-5: Search results page responds quickly (< 2 s in test env)."""
        import time
        start = time.time()
        client.get("/products?q=keyboard")
        elapsed = time.time() - start
        assert elapsed < 2.0, (
            f"AC-09-5 FAIL: Search took {elapsed:.2f}s, must be < 2s"
        )
