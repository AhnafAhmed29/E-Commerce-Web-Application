"""
testing/acceptance/test_us06_about_contact.py
US-06: View Company Information (Medium Priority)
"""
import pytest


@pytest.mark.acceptance
@pytest.mark.us06
class TestUS06AboutContact:

    def test_ac06_1_about_page_returns_200(self, client):
        """AC-06-1: About page is accessible and returns 200."""
        resp = client.get("/about")
        assert resp.status_code == 200, "AC-06-1 FAIL: /about must return 200"

    def test_ac06_1_about_has_content(self, client):
        """AC-06-1: About page explains business purpose."""
        resp = client.get("/about")
        data = resp.data.decode("utf-8").lower()
        assert len(data) > 200, "AC-06-1 FAIL: About page must have content"

    def test_ac06_2_contact_page_returns_200(self, client):
        """AC-06-2: Contact page is accessible."""
        resp = client.get("/contact")
        assert resp.status_code == 200, "AC-06-2 FAIL: /contact must return 200"

    def test_ac06_3_nav_has_about_link(self, client):
        """AC-06-3: About/Contact accessible from main navigation."""
        resp = client.get("/")
        data = resp.data.decode("utf-8").lower()
        assert "about" in data, (
            "AC-06-3 FAIL: Navigation must contain a link to About"
        )
