"""
testing/acceptance/test_us10_cart_summary.py
US-10: Checkout-Ready Cart Summary (Low Priority)
"""
import pytest


@pytest.mark.acceptance
@pytest.mark.us10
class TestUS10CartSummary:

    def _add(self, client, app, slug):
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=slug).first()
            pid = p.id
        client.post("/cart/add", data={"product_id": pid, "quantity": 1},
                    follow_redirects=True)

    def test_ac10_1_cart_lists_products(self, logged_in_customer, sample_product, app):
        """AC-10-1: Cart page displays selected products."""
        self._add(logged_in_customer, app, sample_product)
        resp = logged_in_customer.get("/cart")
        assert resp.status_code == 200

    def test_ac10_3_total_visible(self, logged_in_customer, sample_product, app):
        """AC-10-3: Total order cost is visible on cart page."""
        self._add(logged_in_customer, app, sample_product)
        resp = logged_in_customer.get("/cart")
        assert b"total" in resp.data.lower() or b"Total" in resp.data

    def test_ac10_4_checkout_button_present(self, logged_in_customer, sample_product, app):
        """AC-10-4: Checkout CTA is present on cart page."""
        self._add(logged_in_customer, app, sample_product)
        resp = logged_in_customer.get("/cart")
        data = resp.data.decode().lower()
        assert "checkout" in data or "proceed" in data
