"""
testing/acceptance/test_us05_responsive_access.py
US-05: Responsive Website Access (Medium Priority)
"""
import pytest


@pytest.mark.acceptance
@pytest.mark.us05
class TestUS05ResponsiveAccess:
    """AC-05: Website works across devices."""

    def test_ac05_viewport_meta_on_index(self, client):
        """AC-05-1: Viewport meta tag present on home page."""
        resp = client.get("/")
        assert b"viewport" in resp.data

    def test_ac05_viewport_meta_on_products(self, client):
        """AC-05-1: Viewport meta tag present on products page."""
        resp = client.get("/products")
        assert b"viewport" in resp.data

    def test_ac05_responsive_css_linked(self, client):
        """AC-05-1/3: responsive.css is linked in base layout."""
        resp = client.get("/")
        data = resp.data.decode("utf-8")
        assert "responsive" in data.lower() or "css" in data.lower(), (
            "AC-05 FAIL: Responsive stylesheet must be linked"
        )

    def test_ac05_nav_links_present(self, client):
        """AC-05-2: Navigation links are present in the HTML."""
        resp = client.get("/")
        data = resp.data.decode("utf-8").lower()
        assert "nav" in data or "menu" in data or "href" in data, (
            "AC-05-2 FAIL: Navigation must be present in the HTML"
        )
