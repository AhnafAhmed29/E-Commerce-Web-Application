"""
testing/acceptance/test_us01_view_products.py
─────────────────────────────────────────────────────────────────────────────
Acceptance Tests for US-01: View Products
Priority: HIGH

User Story:
  As a customer, I want to browse all available products by category,
  so that I can easily find gadgets I am interested in.

Acceptance Criteria:
  AC-01-1  The system displays a list of products retrieved from the database.
  AC-01-2  Products are grouped by category.
  AC-01-3  Each product displays its name, image, and price.
  AC-01-4  The page renders correctly on both desktop and mobile devices.
─────────────────────────────────────────────────────────────────────────────
"""
import pytest


@pytest.mark.acceptance
@pytest.mark.us01
class TestUS01ViewProducts:
    """Acceptance tests for US-01: View Products."""

    def test_ac01_1_products_page_returns_200(self, client, sample_product):
        """
        AC-01-1: The system displays a list of products retrieved from the DB.
        Verifies the /products route returns HTTP 200 with product data.
        """
        response = client.get("/products")
        assert response.status_code == 200, (
            "AC-01-1 FAIL: /products must return 200 OK"
        )

    def test_ac01_1_product_names_in_response(self, client, sample_product):
        """
        AC-01-1: Product names retrieved from the database appear in the page.
        """
        response = client.get("/products")
        data = response.data.decode("utf-8")
        # The seeded product name should appear
        assert "AULA F75 Test" in data or "product" in data.lower(), (
            "AC-01-1 FAIL: Product list page must include product names from DB"
        )

    def test_ac01_2_category_filter_works(self, client, sample_product):
        """
        AC-01-2: Products are grouped by category.
        Verifies category slug filtering returns 200 with relevant content.
        """
        response = client.get("/products?category=keyboards")
        assert response.status_code == 200, (
            "AC-01-2 FAIL: Category filter must return 200"
        )

    def test_ac01_2_home_page_has_categories(self, client, sample_category):
        """
        AC-01-2: Homepage exposes category groupings.
        """
        response = client.get("/")
        assert response.status_code == 200
        data = response.data.decode("utf-8")
        assert "Keyboards" in data or "category" in data.lower(), (
            "AC-01-2 FAIL: Homepage must present category groupings"
        )

    def test_ac01_3_product_card_has_name_and_price(self, client, sample_product):
        """
        AC-01-3: Each product displays name and price.
        """
        response = client.get("/products")
        data = response.data.decode("utf-8")
        # Price format: should contain a numeric value
        assert any(c.isdigit() for c in data), (
            "AC-01-3 FAIL: Product listing must show numeric prices"
        )

    def test_ac01_4_products_page_has_responsive_meta(self, client):
        """
        AC-01-4: Page includes viewport meta tag for responsive rendering.
        """
        response = client.get("/products")
        data = response.data.decode("utf-8")
        assert 'viewport' in data, (
            "AC-01-4 FAIL: Page must include viewport meta for responsive design"
        )

    def test_ac01_1_index_page_loads(self, client):
        """
        AC-01-1: Home/index page is accessible and returns 200.
        """
        response = client.get("/")
        assert response.status_code == 200
