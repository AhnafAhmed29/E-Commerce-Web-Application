"""
testing/acceptance/test_us03_add_to_cart.py
─────────────────────────────────────────────────────────────────────────────
Acceptance Tests for US-03: Add Product to Cart
Priority: HIGH

User Story:
  As a customer, I want to add products to my shopping cart,
  so that I can purchase multiple items together.

Acceptance Criteria:
  AC-03-1  The user can add a product to the cart from the product details page.
  AC-03-2  The cart stores selected items using session management.
  AC-03-3  The system prevents adding products beyond available stock.
  AC-03-4  A confirmation is shown when a product is added successfully.
─────────────────────────────────────────────────────────────────────────────
"""
import pytest


@pytest.mark.acceptance
@pytest.mark.us03
class TestUS03AddToCart:
    """Acceptance tests for US-03: Add Product to Cart."""

    def test_ac03_1_add_to_cart_redirects_or_200(
        self, logged_in_customer, sample_product, app
    ):
        """
        AC-03-1: Authenticated user can add a product to the cart.
        Expects either a redirect (302) or direct OK (200).
        """
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=sample_product).first()
            product_id = p.id

        response = logged_in_customer.post(
            "/cart/add",
            data={"product_id": product_id, "quantity": 1},
            follow_redirects=False,
        )
        assert response.status_code in (200, 302), (
            "AC-03-1 FAIL: Adding to cart must succeed (200 or 302)"
        )

    def test_ac03_2_cart_session_persists(
        self, logged_in_customer, sample_product, app
    ):
        """
        AC-03-2: Cart stores selected items; cart page shows the added product.
        """
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=sample_product).first()
            product_id = p.id

        logged_in_customer.post(
            "/cart/add",
            data={"product_id": product_id, "quantity": 1},
            follow_redirects=True,
        )
        cart_response = logged_in_customer.get("/cart", follow_redirects=True)
        assert cart_response.status_code == 200
        data = cart_response.data.decode("utf-8")
        assert "AULA F75" in data or "cart" in data.lower(), (
            "AC-03-2 FAIL: Added product must appear in cart page"
        )

    def test_ac03_3_out_of_stock_cannot_be_added(
        self, logged_in_customer, out_of_stock_product, app
    ):
        """
        AC-03-3: Out-of-stock products cannot be added to the cart.
        Server should respond with an error message or non-success status.
        """
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=out_of_stock_product).first()
            product_id = p.id

        response = logged_in_customer.post(
            "/cart/add",
            data={"product_id": product_id, "quantity": 1},
            follow_redirects=True,
        )
        data = response.data.decode("utf-8").lower()
        # Expect either an error flash message or cart still empty
        has_error = (
            "out of stock" in data
            or "unavailable" in data
            or "cannot" in data
            or "stock" in data
        )
        assert has_error or response.status_code == 400, (
            "AC-03-3 FAIL: Adding OOS product should be rejected"
        )

    def test_ac03_4_success_message_shown(
        self, logged_in_customer, sample_product, app
    ):
        """
        AC-03-4: A success confirmation is shown after adding a product.
        """
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=sample_product).first()
            product_id = p.id

        response = logged_in_customer.post(
            "/cart/add",
            data={"product_id": product_id, "quantity": 1},
            follow_redirects=True,
        )
        data = response.data.decode("utf-8").lower()
        # Accept flash message or JSON success flag
        has_confirmation = (
            "added" in data
            or "success" in data
            or "cart" in data
        )
        assert has_confirmation, (
            "AC-03-4 FAIL: Confirmation must be shown after adding to cart"
        )
