"""
testing/acceptance/test_us13_authentication.py
US-13: User & Admin Registration and Login (High Priority)

Acceptance Criteria:
  AC-13-1  Separate User and Admin login access.
  AC-13-2  New users can sign up using email and password.
  AC-13-3  The system validates credentials during login.
  AC-13-4  Passwords are securely stored using hashing.
  AC-13-5  Logged-in users can maintain a session until logout.
  AC-13-6  Admin users can access restricted admin features.
  AC-13-7  Invalid login attempts display clear error messages.
  AC-13-8  Unauthorized users cannot access admin features.
"""
import pytest
import secrets


@pytest.mark.acceptance
@pytest.mark.us13
class TestUS13Authentication:

    def test_ac13_1_login_page_accessible(self, client):
        """AC-13-1: Login page returns 200."""
        resp = client.get("/login")
        assert resp.status_code == 200

    def test_ac13_1_register_page_accessible(self, client):
        """AC-13-1: Register page returns 200."""
        resp = client.get("/register")
        assert resp.status_code == 200

    def test_ac13_2_new_user_registration(self, client, app):
        """AC-13-2: A new user can register with email and password."""
        suffix = secrets.token_hex(4)
        resp = client.post("/register", data={
            "email": f"newuser_{suffix}@test.com",
            "username": f"newuser_{suffix}",
            "password": "newpass123",
            "confirm_password": "newpass123",
            "first_name": "New",
            "last_name": "User",
        }, follow_redirects=True)
        assert resp.status_code == 200
        data = resp.data.decode().lower()
        assert "login" in data or "success" in data or "welcome" in data, (
            "AC-13-2 FAIL: Registration must lead to login or success page"
        )

    def test_ac13_3_valid_login_succeeds(self, client, customer_user):
        """AC-13-3: Valid credentials are accepted."""
        resp = client.post("/login", data={
            "identifier": customer_user["email"],
            "password": customer_user["password"],
        }, follow_redirects=True)
        assert resp.status_code == 200
        data = resp.data.decode().lower()
        assert "logout" in data or "dashboard" in data or "welcome" in data or \
               "profile" in data or customer_user["username"] in data, (
            "AC-13-3 FAIL: Valid login must succeed and show logged-in state"
        )

    def test_ac13_4_passwords_hashed(self, app, customer_user):
        """AC-13-4: Passwords stored as hash, not plaintext."""
        from models.user import User
        with app.app_context():
            u = User.query.filter_by(email=customer_user["email"]).first()
            assert u.password_hash != customer_user["password"], (
                "AC-13-4 FAIL: Password must NOT be stored in plaintext"
            )
            assert len(u.password_hash) > 20, "AC-13-4 FAIL: Hash too short"

    def test_ac13_5_session_persists_after_login(self, logged_in_customer):
        """AC-13-5: Session persists — protected route is accessible after login."""
        resp = logged_in_customer.get("/orders", follow_redirects=True)
        assert resp.status_code == 200
        data = resp.data.decode().lower()
        assert "login" not in data or "orders" in data, (
            "AC-13-5 FAIL: Logged-in user must access protected routes"
        )

    def test_ac13_6_admin_can_access_dashboard(self, logged_in_admin):
        """AC-13-6: Admin users access the admin dashboard."""
        resp = logged_in_admin.get("/admin/dashboard", follow_redirects=True)
        assert resp.status_code == 200

    def test_ac13_7_invalid_credentials_show_error(self, client):
        """AC-13-7: Invalid credentials display an error message."""
        resp = client.post("/login", data={
            "identifier": "nobody@nowhere.com",
            "password": "wrongpassword",
        }, follow_redirects=True)
        data = resp.data.decode().lower()
        assert ("invalid" in data or "incorrect" in data
                or "error" in data or "failed" in data), (
            "AC-13-7 FAIL: Bad credentials must display an error"
        )

    def test_ac13_8_customer_cannot_access_admin(self, logged_in_customer):
        """AC-13-8: Regular users are denied admin access."""
        resp = logged_in_customer.get("/admin/dashboard", follow_redirects=True)
        data = resp.data.decode().lower()
        assert resp.status_code in (200, 302, 403)
        assert "admin" not in data or "unauthorized" in data or \
               "login" in data or "access" in data or \
               "permission" in data or resp.status_code == 403, (
            "AC-13-8 FAIL: Customers must not access admin panel"
        )

    def test_ac13_8_anonymous_cannot_access_admin(self, client):
        """AC-13-8: Anonymous users are redirected away from admin."""
        resp = client.get("/admin/dashboard", follow_redirects=False)
        assert resp.status_code in (302, 403), (
            "AC-13-8 FAIL: Anonymous users must be redirected from /admin"
        )
