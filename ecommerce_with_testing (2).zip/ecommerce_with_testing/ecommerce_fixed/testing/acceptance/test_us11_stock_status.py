"""
testing/acceptance/test_us11_stock_status.py
US-11: View Product Availability & Stock Status (Medium Priority)

Acceptance Criteria:
  AC-11-1  Each product displays its current stock status.
  AC-11-2  Products marked as out of stock cannot be added to the cart.
  AC-11-3  Stock information is fetched from the database.
  AC-11-4  Stock status is updated automatically when items are added to cart.
"""
import pytest


@pytest.mark.acceptance
@pytest.mark.us11
class TestUS11StockStatus:

    def test_ac11_1_stock_status_on_product_page(self, client, sample_product):
        """AC-11-1: Product detail page shows stock status."""
        resp = client.get(f"/product/{sample_product}")
        data = resp.data.decode().lower()
        assert "stock" in data, "AC-11-1 FAIL: Stock status must appear on product page"

    def test_ac11_1_oos_status_shown(self, client, out_of_stock_product):
        """AC-11-1: Out-of-stock badge shown for unavailable products."""
        resp = client.get(f"/product/{out_of_stock_product}")
        data = resp.data.decode().lower()
        assert "out of stock" in data or "unavailable" in data

    def test_ac11_2_oos_add_to_cart_rejected(self, logged_in_customer, out_of_stock_product, app):
        """AC-11-2: Adding OOS product is rejected by the system."""
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=out_of_stock_product).first()
            pid = p.id
        resp = logged_in_customer.post("/cart/add",
                                       data={"product_id": pid, "quantity": 1},
                                       follow_redirects=True)
        data = resp.data.decode().lower()
        assert ("out of stock" in data or "stock" in data
                or "cannot" in data or resp.status_code == 400), (
            "AC-11-2 FAIL: OOS product add must be rejected"
        )

    def test_ac11_3_stock_from_db(self, app, sample_product):
        """AC-11-3: Stock value is stored in and read from the database."""
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=sample_product).first()
            assert p.stock > 0, "AC-11-3 FAIL: Stock must be stored in DB"

    def test_ac11_1_in_stock_status_property(self, app, sample_product):
        """AC-11-1/3: Product.stock_status returns correct label."""
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=sample_product).first()
            assert p.is_in_stock is True
            assert "In Stock" in p.stock_status or "left" in p.stock_status
