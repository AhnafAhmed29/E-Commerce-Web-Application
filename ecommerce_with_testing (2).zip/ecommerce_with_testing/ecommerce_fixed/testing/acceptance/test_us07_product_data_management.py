"""
testing/acceptance/test_us07_product_data_management.py
US-07: Product Data Management (Medium Priority)
"""
import pytest


@pytest.mark.acceptance
@pytest.mark.us07
class TestUS07ProductDataManagement:

    def test_ac07_1_product_exists_in_db(self, app, sample_product):
        """AC-07-1: Product information is stored in SQLite."""
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=sample_product).first()
            assert p is not None

    def test_ac07_2_product_can_be_updated(self, app, sample_product):
        """AC-07-2: Database supports product updates."""
        from models.db import db
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=sample_product).first()
            original_stock = p.stock
            p.stock = original_stock + 5
            db.session.commit()
            refreshed = Product.query.filter_by(slug=sample_product).first()
            assert refreshed.stock == original_stock + 5
            # Restore
            refreshed.stock = original_stock
            db.session.commit()

    def test_ac07_3_admin_products_page_accessible(
        self, logged_in_admin
    ):
        """AC-07-3: Admin product management page is accessible to admins."""
        resp = logged_in_admin.get("/admin/products", follow_redirects=True)
        assert resp.status_code == 200

    def test_ac07_4_admin_add_product_page_accessible(
        self, logged_in_admin
    ):
        """AC-07-4: Admin can access the add product form."""
        resp = logged_in_admin.get("/admin/products/add",
                                   follow_redirects=True)
        assert resp.status_code == 200
