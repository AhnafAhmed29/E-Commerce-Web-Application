"""
testing/acceptance/test_us02_product_details.py
Acceptance Tests for US-02: View Product Details  |  Priority: HIGH

User Story:
  As a customer, I want to view detailed information about a product,
  so that I can make an informed purchasing decision.

Acceptance Criteria:
  AC-02-1  Clicking a product opens a detailed product page.
  AC-02-2  The page displays name, price, description, specifications,
           and stock status.
  AC-02-3  Product information is loaded from the database.
  AC-02-4  If a product is out of stock, it is clearly indicated.
"""
import pytest


@pytest.mark.acceptance
@pytest.mark.us02
class TestUS02ProductDetails:

    def test_ac02_1_product_detail_page_accessible(self, client, sample_product):
        """AC-02-1: Valid product slug returns 200."""
        response = client.get(f"/product/{sample_product}")
        assert response.status_code == 200, (
            f"AC-02-1 FAIL: /product/{sample_product} must return 200"
        )

    def test_ac02_2_product_name_shown(self, client, sample_product):
        """AC-02-2: Product name appears on the detail page."""
        response = client.get(f"/product/{sample_product}")
        assert b"AULA F75 Test" in response.data, (
            "AC-02-2 FAIL: Product name must appear on the detail page"
        )

    def test_ac02_2_price_shown(self, client, sample_product):
        """AC-02-2: Product price appears on the detail page."""
        response = client.get(f"/product/{sample_product}")
        data = response.data.decode("utf-8")
        assert "4500" in data or "4,500" in data, (
            "AC-02-2 FAIL: Product price must appear on the detail page"
        )

    def test_ac02_2_stock_status_shown(self, client, sample_product):
        """AC-02-2: Stock status is shown on the detail page."""
        response = client.get(f"/product/{sample_product}")
        data = response.data.decode("utf-8").lower()
        assert "stock" in data, (
            "AC-02-2 FAIL: Stock status must appear on the detail page"
        )

    def test_ac02_3_product_loaded_from_db(self, app, sample_product):
        """AC-02-3: Product data is correctly stored in and retrieved from DB."""
        from models.product import Product
        with app.app_context():
            p = Product.query.filter_by(slug=sample_product).first()
            assert p is not None, "AC-02-3 FAIL: Product must exist in DB"
            assert p.price == 4500.0
            assert p.name == "AULA F75 Test"

    def test_ac02_4_out_of_stock_indicated(self, client, out_of_stock_product):
        """AC-02-4: Out-of-stock products show an unavailability indicator."""
        response = client.get(f"/product/{out_of_stock_product}")
        assert response.status_code == 200
        data = response.data.decode("utf-8").lower()
        assert "out of stock" in data or "unavailable" in data, (
            "AC-02-4 FAIL: Out-of-stock products must clearly indicate this"
        )

    def test_ac02_1_invalid_slug_redirects_gracefully(self, client):
        """
        AC-02-1: Non-existent product slug is handled gracefully.
        The app redirects to /products (302) rather than crashing (500).
        This is the documented app behaviour for missing products.
        """
        response = client.get("/product/this-product-does-not-exist-at-all",
                              follow_redirects=False)
        # App does: flash("Product not found") + redirect(url_for('products'))
        assert response.status_code in (302, 404), (
            "AC-02-1 FAIL: Invalid slug must not cause a 500 server error"
        )

    def test_ac02_1_invalid_slug_not_server_error(self, client):
        """AC-02-1: Following the redirect gives a valid products page, not 500."""
        response = client.get("/product/this-product-does-not-exist-at-all",
                              follow_redirects=True)
        assert response.status_code == 200, (
            "AC-02-1 FAIL: Navigating to invalid product must not produce 500"
        )
